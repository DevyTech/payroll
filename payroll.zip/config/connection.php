<?php
$conn = mysqli_connect('localhost', 'root', '', 'db_penggajian') or die('connection to database failed');
